from boardforge import Board, Component, Graphic

# Initialize board
board = Board("Board", 80, 60)
board.set_layer_stack(["GTL", "GBL", "GTO", "GBO"])

# Add components
# CR2032 Battery Holder
battery = Component("BT1", "CR2032", 40, 10)
battery.add_pin("VCC", 0, 0)
battery.add_pin("GND", 10, 0)
battery.add_pad("GTP", "VCC", 0, 0, 2, 2, "circle")
battery.add_pad("GTP", "GND", 10, 0, 2, 2, "circle")
board.add_component(battery)

# Switch
switch = Component("SW1", "SWITCH", 40, 20)
switch.add_pin("A", -2, 0)
switch.add_pin("B", 2, 0)
switch.add_pad("GTP", "A", -2, 0, 1.8, 1.8)
switch.add_pad("GTP", "B", 2, 0, 1.8, 1.8)
board.add_component(switch)

# Resistors
r1 = Component("R1", "RESISTOR", 20, 35)
r1.add_pin("A", -3, 0)
r1.add_pin("B", 3, 0)
r1.add_pad("GTP", "A", -3, 0, 1.6, 1.6)
r1.add_pad("GTP", "B", 3, 0, 1.6, 1.6)
board.add_component(r1)

r2 = Component("R2", "RESISTOR", 40, 35)
r2.add_pin("A", -3, 0)
r2.add_pin("B", 3, 0)
r2.add_pad("GTP", "A", -3, 0, 1.6, 1.6)
r2.add_pad("GTP", "B", 3, 0, 1.6, 1.6)
board.add_component(r2)

r3 = Component("R3", "RESISTOR", 60, 35)
r3.add_pin("A", -3, 0)
r3.add_pin("B", 3, 0)
r3.add_pad("GTP", "A", -3, 0, 1.6, 1.6)
r3.add_pad("GTP", "B", 3, 0, 1.6, 1.6)
board.add_component(r3)

# LEDs
d1 = Component("D1", "LED", 20, 50, 45)
d1.add_pin("A", 0, -2)
d1.add_pin("K", 0, 2)
d1.add_pad("GTP", "A", 0, -2, 1.6, 1.6)
d1.add_pad("GTP", "K", 0, 2, 1.6, 1.6)
board.add_component(d1)

d2 = Component("D2", "LED", 40, 50)
d2.add_pin("A", 0, -2)
d2.add_pin("K", 0, 2)
d2.add_pad("GTP", "A", 0, -2, 1.6, 1.6)
d2.add_pad("GTP", "K", 0, 2, 1.6, 1.6)
board.add_component(d2)

d3 = Component("D3", "LED", 60, 50, -45)
d3.add_pin("A", 0, -2)
d3.add_pin("K", 0, 2)
d3.add_pad("GTP", "A", 0, -2, 1.6, 1.6)
d3.add_pad("GTP", "K", 0, 2, 1.6, 1.6)
board.add_component(d3)

# Add traces with precomputed paths
board.add_trace("GTL", battery.get_pin("VCC"), switch.get_pin("A"),
                path=[(40, 10), (38, 10), (38, 20)])
board.add_trace("GTL", switch.get_pin("B"), r1.get_pin("A"),
                path=[(42, 20), (42, 25), (17, 25), (17, 35)])
board.add_trace("GTL", switch.get_pin("B"), r2.get_pin("A"),
                path=[(42, 20), (42, 35), (37, 35)])
board.add_trace("GTL", switch.get_pin("B"), r3.get_pin("A"),
                path=[(42, 20), (42, 30), (57, 30), (57, 35)])
board.add_trace("GTL", r1.get_pin("B"), d1.get_pin("A"),
                path=[(23, 35), (23, 48.5858), (21.4142, 48.5858)])
board.add_trace("GTL", r2.get_pin("B"), d2.get_pin("A"),
                path=[(43, 35), (43, 48), (40, 48)])
board.add_trace("GTL", r3.get_pin("B"), d3.get_pin("A"),
                path=[(63, 35), (63, 48.5858), (58.5858, 48.5858)])
board.add_trace("GTL", d1.get_pin("K"), battery.get_pin("GND"),
                path=[(18.5858, 51.4142), (30, 51.4142), (30, 10), (50, 10)])
board.add_trace("GTL", d2.get_pin("K"), battery.get_pin("GND"),
                path=[(40, 52), (40, 10), (50, 10)])
board.add_trace("GTL", d3.get_pin("K"), battery.get_pin("GND"),
                path=[(61.4142, 51.4142), (61.4142, 40), (50, 40), (50, 10)])

# Add silkscreen text
for component in [battery, switch, r1, r2, r3, d1, d2, d3]:
    board.add_graphic(Graphic("GTO", None, component.ref, component.x - 4, component.y - 5, 1.2, font="RobotoMono.ttf"))

# Add SVG graphic
import os
if os.path.exists("torch.svg"):
    board.add_graphic(Graphic("GTO", "torch.svg", None, 5, 5, 1.2))

# Save outputs
board.save_svg_previews("output")
board.export_gerbers("output")