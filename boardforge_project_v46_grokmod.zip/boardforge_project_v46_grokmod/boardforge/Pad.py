import math
import logging

logging.basicConfig(filename='boardforge.log', level=logging.DEBUG)

class Pad:
    def __init__(self, component, layer, pin_name, dx, dy, width, height, shape="rectangle"):
        logging.debug(f"ENTRY Pad.__init__: component={component.ref}, layer={layer}, pin_name={pin_name}, dx={dx}, dy={dy}, width={width}, height={height}, shape={shape}")
        self.component = component
        self.layer = layer
        self.pin_name = pin_name
        self.dx = dx
        self.dy = dy
        self.width = width
        self.height = height
        self.shape = shape
        logging.debug(f"EXIT Pad.__init__: self={self.__dict__}")

    def get_position(self, x, y, theta):
        logging.debug(f"ENTRY Pad.get_position: x={x}, y={y}, theta={theta}")
        rad = math.radians(theta)
        cos_theta = math.cos(rad)
        sin_theta = math.sin(rad)
        px = x + (self.dx * cos_theta - self.dy * sin_theta)
        py = y + (self.dx * sin_theta + self.dy * cos_theta)
        logging.debug(f"EXIT Pad.get_position: position=({px}, {py})")
        return px, py
