class Via:

    def __init__(self, x, y, from_layer, to_layer):
        self.x = x
        self.y = y
        self.from_layer = from_layer
        self.to_layer = to_layer

