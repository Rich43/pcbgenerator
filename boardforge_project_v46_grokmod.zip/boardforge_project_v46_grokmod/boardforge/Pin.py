import math
import logging

logging.basicConfig(filename='boardforge.log', level=logging.DEBUG)

class Pin:
    def __init__(self, name, component, comp_at, dx, dy, theta):
        logging.debug(f"ENTRY Pin.__init__: name={name}, comp_at={comp_at}, dx={dx}, dy={dy}, theta={theta}")
        self.name = name
        self.component = component
        self.dx = dx
        self.dy = dy
        r = math.radians(theta)
        self.x = comp_at[0] + (dx * math.cos(r) - dy * math.sin(r))
        self.y = comp_at[1] + (dx * math.sin(r) + dy * math.cos(r))
        logging.debug(f"EXIT Pin.__init__: self={self.__dict__}")

    def get_position(self):
        logging.debug(f"ENTRY Pin.get_position: self={self.__dict__}")
        return self.x, self.y