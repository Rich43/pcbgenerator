import math
import logging
from .Pin import Pin
from .Pad import Pad

logging.basicConfig(filename='boardforge.log', level=logging.DEBUG)

class Component:
    def __init__(self, ref, footprint, x, y, theta=0):
        logging.debug(f"ENTRY Component.__init__: ref={ref}, footprint={footprint}, x={x}, y={y}, theta={theta}")
        self.ref = ref
        self.footprint = footprint
        self.x = x
        self.y = y
        self.theta = theta
        self.pins = {}
        self.pads = []
        logging.debug(f"EXIT Component.__init__: self={self.__dict__}")

    def add_pin(self, name, dx, dy):
        logging.debug(f"ENTRY Component.add_pin: name={name}, dx={dx}, dy={dy}")
        pin = Pin(name, self, (self.x, self.y), dx, dy, self.theta)
        self.pins[name] = pin
        logging.debug(f"EXIT Component.add_pin: pin={pin.__dict__}")

    def add_pad(self, layer, pin_name, dx, dy, width, height, shape="rectangle"):
        logging.debug(f"ENTRY Component.add_pad: layer={layer}, pin_name={pin_name}, dx={dx}, dy={dy}, width={width}, height={height}, shape={shape}")
        pad = Pad(self, layer, pin_name, dx, dy, width, height, shape)
        self.pads.append(pad)
        logging.debug(f"EXIT Component.add_pad: pad={pad.__dict__}")

    def get_pin(self, name):
        logging.debug(f"ENTRY Component.get_pin: name={name}")
        pin = self.pins.get(name)
        if pin is None:
            logging.error(f"Pin not found: {name}")
            raise ValueError(f"Pin {name} not found in component {self.ref}")
        logging.debug(f"EXIT Component.get_pin: pin={pin.__dict__}")
        return pin
