import math
import os
import zipfile
import logging
from .Component import Component
from .Graphic import Graphic
from .Via import Via
from . import svgtools

logging.basicConfig(filename='boardforge.log', level=logging.DEBUG)

class Board:
    def __init__(self, name, width, height):
        logging.debug(f"ENTRY Board.__init__: name={name}, width={width}, height={height}")
        self.name = name
        self.width = width
        self.height = height
        self.components = []
        self.vias = []
        self.graphics = []
        self.layer_stack = []
        self.traces = []
        logging.debug(f"EXIT Board.__init__: self={self.__dict__}")

    def set_layer_stack(self, layers):
        logging.debug(f"ENTRY Board.set_layer_stack: layers={layers}")
        self.layer_stack = layers
        logging.debug(f"EXIT Board.set_layer_stack: layer_stack={self.layer_stack}")

    def add_component(self, component):
        logging.debug(f"ENTRY Board.add_component: component={component.__dict__}")
        if not isinstance(component, Component):
            logging.error(f"Invalid component type: {type(component)}")
            raise ValueError("Component must be an instance of Component")
        self.components.append(component)
        logging.debug(f"EXIT Board.add_component: components={len(self.components)}")

    def add_trace(self, layer, pin1, pin2, path=None):
        logging.debug(f"ENTRY Board.add_trace: layer={layer}, pin1={pin1.__dict__}, pin2={pin2.__dict__}, path={path}")
        if layer not in self.layer_stack:
            logging.error(f"Invalid layer: {layer}")
            raise ValueError(f"Layer {layer} not in layer stack")
        if pin1 == pin2:
            logging.error(f"Cannot connect pin to itself: {pin1.__dict__}")
            raise ValueError("Pins must be different")
        self.traces.append((layer, pin1, pin2, path))
        logging.debug(f"EXIT Board.add_trace: traces={len(self.traces)}")

    def add_graphic(self, graphic):
        logging.debug(f"ENTRY Board.add_graphic: graphic={graphic.__dict__}")
        self.graphics.append(graphic)
        logging.debug(f"EXIT Board.add_graphic: graphics={len(self.graphics)}")

    def add_via(self, via):
        logging.debug(f"ENTRY Board.add_via: via={via.__dict__}")
        self.vias.append(via)
        logging.debug(f"EXIT Board.add_via: vias={len(self.vias)}")

    def save_svg_previews(self, output_dir):
        logging.debug(f"ENTRY Board.save_svg_previews: output_dir={output_dir}")
        os.makedirs(output_dir, exist_ok=True)
        
        for layer in self.layer_stack:
            if layer not in ["GTO", "GBO"]:
                continue
            
            svg_elements = []
            # Draw board outline
            svg_elements.append(svgtools.render_rectangle(
                self.width / 2, self.height / 2, self.width, self.height,
                fill="#5d2292", stroke="none", corner_radius=2
            ))
            
            # Draw components and pads
            for component in self.components:
                for pad in component.pads:
                    if pad.layer == layer:
                        x, y = pad.get_position(component.x, component.y, component.theta)
                        y = self.height - y
                        logging.debug(f"Rendering pad for {component.ref} at ({x}, {y})")
                        if pad.shape == "circle":
                            svg_elements.append(svgtools.render_circle(
                                x, y, pad.width / 2, fill="#ffc100", stroke="#ffec80", stroke_width=0.1
                            ))
                        else:
                            svg_elements.append(svgtools.render_rectangle(
                                x, y, pad.width, pad.height, fill="#ffc100", stroke="#ffec80", stroke_width=0.1
                            ))
            
            # Draw traces
            for trace_layer, pin1, pin2, path in self.traces:
                if trace_layer == layer:
                    if path is None:
                        x1, y1 = pin1.get_position()
                        x2, y2 = pin2.get_position()
                        path = [(x1, y1), (x2, y2)]
                    svg_path = [(x, self.height - y) for x, y in path]
                    d = f"M {svg_path[0][0]} {svg_path[0][1]}"
                    for i in range(1, len(svg_path)):
                        x0, y0 = svg_path[i-1]
                        x1, y1 = svg_path[i]
                        if i < len(svg_path) - 1:
                            cx = x0 if x0 == x1 else x1
                            cy = y1 if x0 == x1 else y0
                            d += f" Q {cx} {cy + (0.5 if y0 > y1 else -0.5)} {x1} {y1}"
                        else:
                            d += f" L {x1} {y1}"
                    svg_elements.append(svgtools.render_path(d, stroke="#ffc100", stroke_width=0.3))
                    logging.debug(f"Rendering trace from {path[0]} to {path[-1]}: {d}")
            
            # Draw graphics
            for graphic in self.graphics:
                if graphic.layer == layer:
                    y = self.height - graphic.y
                    logging.debug(f"Rendering graphic at ({graphic.x}, {y})")
                    try:
                        svg_elements.append(svgtools.render_svg_element(
                            graphic.filename, graphic.x, y, graphic.scale
                        ))
                    except Exception as e:
                        logging.error(f"Failed to render graphic {graphic.filename}: {e}")
            
            # Save SVG file
            svg_content = svgtools.create_svg(self.width, self.height, svg_elements)
            filename = os.path.join(output_dir, f"preview_{'top' if layer == 'GTO' else 'bottom'}.svg")
            with open(filename, "w") as f:
                f.write(svg_content)
            logging.debug(f"Saved SVG preview: {filename}")
        
        logging.debug("EXIT Board.save_svg_previews")

    def export_gerbers(self, output_dir):
        logging.debug(f"ENTRY Board.export_gerbers: output_dir={output_dir}")
        os.makedirs(output_dir, exist_ok=True)
        temp_dir = os.path.join(output_dir, "temp_gerbers")
        os.makedirs(temp_dir, exist_ok=True)
        
        from .GerberExporter import GerberExporter
        exporter = GerberExporter(self)
        exporter.export(temp_dir)
        
        zip_path = os.path.join(output_dir, f"{self.name}_output.zip")
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    zipf.write(os.path.join(root, file), os.path.join("gerbers", file))
        
        import shutil
        shutil.rmtree(temp_dir)
        logging.debug(f"EXIT Board.export_gerbers: zip_path={zip_path}")